-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 30-05-2022 a las 09:56:42
-- Versión del servidor: 10.3.34-MariaDB-0ubuntu0.20.04.1
-- Versión de PHP: 7.3.33-1+focal

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `whit_whiteflashDataBase`
--
CREATE DATABASE IF NOT EXISTS `whit_whiteflashDataBase` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `whit_whiteflashDataBase`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id` int(11) NOT NULL,
  `nombre` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id`, `nombre`) VALUES
(1, 'Tecnología'),
(2, 'Deportes'),
(3, 'Mascotas'),
(4, 'Libros'),
(5, 'Peliculas');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellidos` varchar(60) NOT NULL,
  `email` varchar(60) DEFAULT NULL,
  `contrasenya` varchar(40) DEFAULT NULL,
  `telefono` int(11) DEFAULT NULL,
  `direccion` varchar(60) NOT NULL,
  `ciudad` varchar(50) DEFAULT NULL,
  `pais` int(11) DEFAULT NULL,
  `admin` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalles_producto`
--

CREATE TABLE `detalles_producto` (
  `pedido_id` int(11) NOT NULL,
  `producto_id` int(11) NOT NULL,
  `precio` float DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paises`
--

CREATE TABLE `paises` (
  `id` int(11) NOT NULL,
  `nombre` varchar(60) CHARACTER SET utf8mb4 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `paises`
--

INSERT INTO `paises` (`id`, `nombre`) VALUES
(1, 'España'),
(2, 'Francia'),
(3, 'Portugal'),
(4, 'Alemania'),
(5, 'Andorra'),
(6, 'Reino Unido'),
(7, 'Irlanda'),
(8, 'Italia'),
(9, 'Noruega'),
(10, 'Belgica');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos`
--

CREATE TABLE `pedidos` (
  `id` int(11) NOT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `direccion_facturacion` varchar(60) CHARACTER SET utf8mb4 DEFAULT NULL,
  `direccion_envio` varchar(60) CHARACTER SET utf8mb4 DEFAULT NULL,
  `email_cliente` varchar(60) CHARACTER SET utf8mb4 DEFAULT NULL,
  `fecha_pedido` date DEFAULT NULL,
  `estado_pedido` varchar(30) CHARACTER SET utf8mb4 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `precio` float DEFAULT NULL,
  `descripcion` varchar(500) DEFAULT NULL,
  `imagen` varchar(200) DEFAULT NULL,
  `categoria` int(11) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `nombre`, `precio`, `descripcion`, `imagen`, `categoria`, `stock`) VALUES
(2, 'Monitor Gaming QHD 27\" Odyssey G5 165hz LS27AG500NU', 250, 'Monitor Curvo de 24 pulgadas VA (1920x1080p), Tasa de refresco de 165 Hz y un tiempo de respuesta de 1 ms que proporciona lamejor experiencia gaming. Tiene un ángulo de visión de 178/178, un brillo de 250cd/m2 y un contraste de 3000:1. Producto Millenium diseñado y desarrollado por gamers. Confort visual que te asegura un máximo rendimiento', 'https://whiteflash.ddns.net/imagenesProductos/MONITOR.jpg', 1, 1),
(3, 'TCL 10 Pro 6', 140, '6.47\" FHD+ (398 ppi) Amoled Snapdragon 675 (215.000 Antutu). 6GB RAM - 128GB +SD. 4 Cámaras: 64+16+5+2 Mpx (1.7) | 20 Mpx selfie. 4500mAh', 'https://whiteflash.ddns.net/imagenesProductos/telefono.jpg', 1, 1),
(4, 'Mando inalámbrico DualSense Sony Negro PS5', 50, 'Inmersiva retroalimentación háptica, gatillos adaptativos dinámicos y un micrófono integrado', 'https://whiteflash.ddns.net/imagenesProductos/mandops5.jpg', 1, 1),
(5, '4.	65” Samsung Series 9 UE65AU9005K 4K UHD HDR10+', 595, 'Samsung Series 9 UE65AU9005K. Diagonal de la pantalla: 165,1 cm (65\"), Resolución de la pantalla: 3840 x 2160 Pixeles, Tipo HD: 4K Ultra HD, Tecnología de visualización: LED, Forma de la pantalla: Plana. Smart TV. Tecnología de interpolación de movimiento: PQI', 'https://whiteflash.ddns.net/imagenesProductos/TV.jpg', 1, 1),
(6, '\r\n5.	AMD Ryzen 5 5600G 4.40GHz', 167, 'descripcion;\r\nN.° de núcleos de CPU 6\r\nN.° de subprocesos 12\r\nN.° de núcleos de GPU 7\r\nReloj base 3.9GHz', 'https://whiteflash.ddns.net/imagenesProductos/procesador.jpg', 1, 1),
(7, '1.	ADIDAS ADIPOWER CTRL LITE', 150, 'Esta pala adquiere una combinación de la goma EVA SOFT PERFORMANCE con la superficie en FIBER GLASS, \r\n\r\nPosee la tecnología dual eXoeskeleton, un extra de rigidez gracias a la incorporación de fibras de carbono integrados en el corazón de la pala.\r\n', 'https://whiteflash.ddns.net/imagenesProductos/padelapadel.jpg', 2, 1),
(8, 'SKILLS - Balón de baloncesto', 15, '57 cm (talla One Size)', 'https://whiteflash.ddns.net/imagenesProductos/balon.png', 2, 1),
(9, 'CAJON PELOTAS HEAD CS', 70, ': Las Pelotas Head Cs son unas de las bolas que tienen una mejor calidad-precio. Son muy utilizadas por los monitores por la alta durabilidad y el precio competitivo que tienen', 'https://whiteflash.ddns.net/imagenesProductos/pelotastenis.jpg', 2, 1),
(10, '101 cosas que deberías hacer antes de ser mayor', 11.5, 'Hacer malabarismos, criar mariposas, hacer un truco de magia, crear un código secreto, montar un volcán casero... y otras 96 divertidas actividades para tachar de la lista de cosas que hay que aprender a hacer antes de ser mayor. ¿Cuántas serás capaz de tachar?', 'https://whiteflash.ddns.net/imagenesProductos/libro1.jpg', 4, 1),
(11, 'Canasta de basket para adultos Raycool STARS 700', 380, 'Te presentamos la nueva canasta de baloncesto Raycool Stars 700. ¿Quieres dejar de pasar el tiempo en el sofá enganchado a tu smartphone? ¿Tus hijos solo quieren jugar a videojuegos? ¡Fomenta el deporte y en tu propia casa con la nueva canasta Raycool Stars 700! Pásalo en grande con la llegada del buen tiempo, podrás disfrutar de partidos con tus amigos, con tus hijos y con quien quieras. Te pondrás en forma y te divertirás sin salir de la comodidad de tu hogar.', 'https://whiteflash.ddns.net/imagenesProductos/canasta.jpg', 2, 1),
(12, 'La cuenta atrás para el verano', 17, 'La Vecina Rubia llega a las librerías con un relato emocional en el que la protagonista narra uno de los aprendizajes más importantes de su vida: el paso de la adolescencia a la madurez. ', 'https://whiteflash.ddns.net/imagenesProductos/libro2.jpg', 4, 1),
(13, 'Disco Volador 175g Discraft', 17, 'Disco oficial de las USA Ultimate Championship Series.', 'https://whiteflash.ddns.net/imagenesProductos/frisbi.jpg', 2, 1),
(14, 'Anna Kadabra 9. Un lobo en escena ', 9.45, 'Anna y sus amigos están montando una obra de teatro sobre Lobelia de Loboblanco, la más famosa hechicera de Moonville. ¡Y también la más misteriosa! Algunos vecinos la consideran una gran heroína que ayudó a todos con su magia. Otros creen que fue una bruja malvada que hechizó a un enorme lobo para que atacara al pueblo, pero… ¿qué ocurrió realmente?', 'https://whiteflash.ddns.net/imagenesProductos/libro3.jpg', 4, 1),
(15, 'Cama acolchada con rebordes para mascotas', 32.31, 'Perfecta para colocar en una residencia canina, en un portador o en cualquier lugar en el que tu mascota quiera dormir, el forro polar sherpa sintético de esta cama garantiza una sensación de felicidad y calidez.', 'https://whiteflash.ddns.net/imagenesProductos/cama.jpg', 3, 1),
(16, 'EL SUTIL ARTE DE QUE (CASI TODO) TE IMPORTE UNA MIERDA', 15, 'En esta guía de autoayuda, el bestseller internacional que está definiendo a toda una generación, el bloguero superestrella Mark Manson nos demuestra que la clave para ser personas más seguras y felices es manejar de mejor forma la adversidad. ¡A la mierda con la positividad!', 'https://whiteflash.ddns.net/imagenesProductos/libro4.jpg', 4, 1),
(17, 'Curver 221088 Caseta de Perro, 95 x 99 x 99 cm, Color Gris', 90, 'Una casa para perros que te encantará ver y a la que le encantará que esté tu perro. Fabricada en resina duradera, esta casa para perros resiste los daños causados por el clima, por lo que es una solución de bajo mantenimiento. También cuenta con toques de diseño moderno y tiene un piso elevado para la calidez y la sequedad y un gran interior con el que su perro puede moverse fácilmente.', 'https://whiteflash.ddns.net/imagenesProductos/casaperro.jpg', 3, 1),
(18, 'ARTA en el apocalipsis máximo', 14.2, 'En la Tierra están pasando cosas extrañas: PRIMERO, los volcanes del mundo han entrado en erupción. DESPUÉS, ha habido un gran apagón. AHORA han aparecido bichos raros por todas partes.\r\n', 'https://whiteflash.ddns.net/imagenesProductos/libro5.jpg', 4, 1),
(19, 'Edipets, Arbol Rascador para Gatos, 4 Niveles', 80, 'Está recubierto de terciopelo, proporcionando una suavidad extra que favorece la comodidad y el bienestar de tu mascota. Los postes recubiertos de cuerda de sisal son el lugar perfecto para que nuestros amigos felinos afilen sus uñas.', 'https://whiteflash.ddns.net/imagenesProductos/gatos_.jpg', 3, 1),
(20, 'MUALROUS Patio de Juegos Para Pájaros Loros ', 26, ': MADERA NATURAL: el puesto de juegos Porrot está hecho de madera y todas las partes están conectadas con tornillos, no con pegamento. De esta manera, el gimnasio de juegos para pájaros es más resistente y más estable', 'https://whiteflash.ddns.net/imagenesProductos/periquito.jpg', 3, 1),
(21, 'Alimento seco completo para perro adulto rico en pollo con guisantes ', 20, 'cereales (maíz), carne y derivados de origen animal: aprox. 27 % (mín. 14 % de pollo), aceites y grasas (mín. 4 % de grasa de ave), verduras (mín. 4 % de guisantes), derivados de origen vegetal (mín. 1 % de pulpa de remolacha, 0,01 % de yuca de Mojave)', 'https://whiteflash.ddns.net/imagenesProductos/perrito.jpg', 3, 1),
(22, 'Colección Mini-pelis - DVD', 7.9, '¡Por primera vez puedes disfrutar de una gran colección de 7 mini-películas protagonizadas por tus personajes favoritos de Gru, Hop y el Lorax! Ponte las pilas con los Minions, salta junto a Phil y Carlos y explora la naturaleza con el Lorax, todo en estas formidables aventuras repletas de risas. Se trata, pues, de diversión muy animada para toda la familia que podrás pasártelo de maravilla una y otra vez.', 'https://whiteflash.ddns.net/imagenesProductos/peli1.jpg', 5, 1),
(23, 'Spider-Man: No Way Home (Blu-ray)', 20, 'Action, Sci-Fi, Adventure', 'https://whiteflash.ddns.net/imagenesProductos/masvendido1.jpg', 5, 1),
(24, 'John Wick: Pacto De Sangre [DVD]', NULL, 'Clasificado ‏ : ‎ No recomendada para menores de 18 años\r\nDimensiones del producto ‏ : ‎ 13.6 x 1.5 x 19.2 cm; 70 gramos', 'https://whiteflash.ddns.net/imagenesProductos/peli4.jpg', NULL, NULL),
(25, 'El Chiringuito de Pepe - Serie Completa [DVD]', 22.5, 'Relación de aspecto ‏ : ‎ Desconocido\r\nClasificado ‏ : ‎ No recomendada para menores de 7 años\r\nDimensiones del paquete ‏ : ‎ 18.03 x 13.76 x 1.48 cm; 83.16 gramos', 'https://whiteflash.ddns.net/imagenesProductos/', 5, 1),
(26, 'El Principito', 1.7, 'La amistad entre una Niña a la que su exigente madre está preparando para vivir en el mundo de los adultos y su vecino, un anciano Aviador, bondadoso y excéntrico que revela a su nueva amiga un mundo extraordinario donde todo es posible.', 'https://whiteflash.ddns.net/imagenesProductos/peli3.jpg', 5, 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pais` (`pais`);

--
-- Indices de la tabla `detalles_producto`
--
ALTER TABLE `detalles_producto`
  ADD PRIMARY KEY (`pedido_id`,`producto_id`),
  ADD KEY `producto_id` (`producto_id`);

--
-- Indices de la tabla `paises`
--
ALTER TABLE `paises`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id`) USING BTREE,
  ADD KEY `cliente_id` (`cliente_id`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `categoria` (`categoria`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `paises`
--
ALTER TABLE `paises`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD CONSTRAINT `clientes_ibfk_1` FOREIGN KEY (`pais`) REFERENCES `paises` (`id`);

--
-- Filtros para la tabla `detalles_producto`
--
ALTER TABLE `detalles_producto`
  ADD CONSTRAINT `detalles_producto_ibfk_1` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`);

--
-- Filtros para la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `pedidos_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`),
  ADD CONSTRAINT `pedidos_ibfk_2` FOREIGN KEY (`id`) REFERENCES `detalles_producto` (`pedido_id`);

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`categoria`) REFERENCES `categorias` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
